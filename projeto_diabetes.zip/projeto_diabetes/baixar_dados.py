
from pathlib import Path

from sklearn.datasets import fetch_openml

RENOMEAR = {
    "preg": "Pregnancies", "plas": "Glucose", "pres": "BloodPressure", "skin": "SkinThickness",
    "insu": "Insulin", "mass": "BMI", "pedi": "DiabetesPedigreeFunction", "age": "Age",
}

df = fetch_openml(data_id=37, as_frame=True).frame.rename(columns=RENOMEAR)
df["Outcome"] = (df["class"] == "tested_positive").astype(int)
df = df.drop(columns="class")

destino = Path(__file__).parent / "data" / "diabetes.csv"
df.to_csv(destino, index=False)
print(f"{len(df)} registros salvos em {destino}")
