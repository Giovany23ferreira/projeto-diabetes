
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

import joblib
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

import dados

RAIZ = Path(__file__).parent
CSV_PADRAO = RAIZ / "data" / "diabetes.csv"
SAIDA_MODELO = RAIZ / "models" / "modelo.joblib"
SAIDA_METRICAS = RAIZ / "models" / "metricas.json"

TEST_SIZE = 0.20
RANDOM_STATE = 42


def montar_modelos():
    """Três classificadores permitidos no enunciado, cada um com seu pré-processamento."""
    mediana = lambda: SimpleImputer(strategy="median")
    return {
        # Regressão logística precisa de escala parecida entre as variáveis
        "Regressão Logística": Pipeline([
            ("imputador", mediana()), ("escala", StandardScaler()),
            ("modelo", LogisticRegression(max_iter=1000, class_weight="balanced"))]),
        # Árvores não precisam de escala
        "Random Forest": Pipeline([
            ("imputador", mediana()),
            ("modelo", RandomForestClassifier(n_estimators=300, max_depth=6, min_samples_leaf=3,
                                              class_weight="balanced", random_state=RANDOM_STATE))]),
        "Árvore de Decisão": Pipeline([
            ("imputador", mediana()),
            ("modelo", DecisionTreeClassifier(max_depth=4, min_samples_leaf=5,
                                              class_weight="balanced", random_state=RANDOM_STATE))]),
    }


def main(caminho_csv: Path):
    if not caminho_csv.exists():
        sys.exit(f"Arquivo {caminho_csv} não encontrado. Rode antes:  python baixar_dados.py")

    bruto = caminho_csv.read_bytes()
    original, _ = dados.ler_csv(bruto)
    df, log, diag = dados.limpar(original)
    dados.validar_minimo(df)
    print(f"Base: {diag['antes']} registros antes da limpeza, {diag['depois']} depois.")

    X, y = df[dados.COLUNAS_X], df[dados.ALVO].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y)
    baseline = max(y_test.mean(), 1 - y_test.mean())
    print(f"Treino: {len(X_train)} | Teste: {len(X_test)} | baseline (classe mais frequente): {baseline:.1%}\n")

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    resultados, treinados = [], {}
    for nome, pipe in montar_modelos().items():
        cv_f1 = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="f1")  # só com o treino
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)
        prob = pipe.predict_proba(X_test)[:, 1]
        res = {
            "nome": nome,
            "acuracia": accuracy_score(y_test, y_pred),
            "precisao": precision_score(y_test, y_pred, zero_division=0),
            "recall": recall_score(y_test, y_pred),
            "f1": f1_score(y_test, y_pred),
            "roc_auc": roc_auc_score(y_test, prob),
            "cv_f1_media": float(cv_f1.mean()),
            "cv_f1_desvio": float(cv_f1.std()),
            "matriz": confusion_matrix(y_test, y_pred).tolist(),  # [[VN, FP], [FN, VP]]
        }
        resultados.append(res)
        treinados[nome] = pipe
        print(f"{nome:20s} acc={res['acuracia']:.3f} prec={res['precisao']:.3f} "
              f"rec={res['recall']:.3f} f1={res['f1']:.3f} auc={res['roc_auc']:.3f} "
              f"| CV-F1 treino={res['cv_f1_media']:.3f}±{res['cv_f1_desvio']:.3f}")

    melhor = max(resultados, key=lambda r: r["cv_f1_media"])
    vn, fp, fn, vp = (v for linha in melhor["matriz"] for v in linha)
    justificativa = (
        f"{melhor['nome']} teve o maior F1 médio na validação cruzada do conjunto de treino "
        f"({melhor['cv_f1_media']:.3f}). No teste, acertou {melhor['acuracia']:.1%} "
        f"(baseline {baseline:.1%}), com recall de {melhor['recall']:.1%} e precisão de {melhor['precisao']:.1%} "
        f"para a classe com diabetes. Entre {vp + fn} pacientes com diabetes no teste, {fn} não foram "
        f"detectadas (falsos negativos) e {fp} pacientes sem diabetes foram sinalizadas por engano (falsos positivos)."
    )
    print(f"\nEscolhido: {melhor['nome']}\n{justificativa}")

    SAIDA_MODELO.parent.mkdir(exist_ok=True)
    joblib.dump(treinados[melhor["nome"]], SAIDA_MODELO)  # o pipeline guarda imputador + escala + modelo

    metricas = {
        "base": {
            "arquivo": caminho_csv.name,
            "sha256": hashlib.sha256(bruto).hexdigest()[:12],
            "registros_antes": diag["antes"],
            "registros_depois": diag["depois"],
            "zeros_invalidos": diag["zeros_invalidos"],
            "classes": {str(k): int(v) for k, v in y.value_counts().items()},
        },
        "divisao": {
            "test_size": TEST_SIZE, "random_state": RANDOM_STATE,
            "n_treino": len(X_train), "n_teste": len(X_test),
            "distribuicao_teste": {str(k): int(v) for k, v in y_test.value_counts().items()},
            "baseline_acuracia": baseline,
        },
        "modelos": resultados,
        "escolhido": melhor["nome"],
        "criterio": "maior F1 médio na validação cruzada (5 folds) do conjunto de treino",
        "justificativa": justificativa,
        "features": dados.COLUNAS_X,
        "sklearn": sklearn.__version__,
        "treinado_em": datetime.now().strftime("%d/%m/%Y %H:%M"),
    }
    SAIDA_METRICAS.write_text(json.dumps(metricas, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nSalvo: {SAIDA_MODELO.name} e {SAIDA_METRICAS.name} em models/")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else CSV_PADRAO)
