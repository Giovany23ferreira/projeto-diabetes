
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from dados import COLUNAS_X, ROTULOS_CLASSE

RAIZ = Path(__file__).parent
CAMINHO_MODELO = RAIZ / "models" / "modelo.joblib"
CAMINHO_METRICAS = RAIZ / "models" / "metricas.json"

_cache = {}

CAMPOS = [
    {"nome": "Pregnancies", "rotulo": "Número de gestações", "unidade": "", "min": 0, "max": 20, "passo": 1,
     "obrigatorio": True, "dica": "0 se nunca engravidou"},
    {"nome": "Glucose", "rotulo": "Glicose", "unidade": "mg/dL", "min": 40, "max": 400, "passo": 1,
     "obrigatorio": True, "dica": "Glicose 2 h após teste oral de tolerância"},
    {"nome": "BloodPressure", "rotulo": "Pressão arterial diastólica", "unidade": "mm Hg", "min": 30, "max": 200,
     "passo": 1, "obrigatorio": True, "dica": "O número menor da pressão (ex.: 70)"},
    {"nome": "SkinThickness", "rotulo": "Dobra cutânea do tríceps", "unidade": "mm", "min": 5, "max": 100,
     "passo": 1, "obrigatorio": False, "dica": "Opcional: se vazio, usa a mediana do treino"},
    {"nome": "Insulin", "rotulo": "Insulina sérica (2 h)", "unidade": "mu U/ml", "min": 10, "max": 900,
     "passo": 1, "obrigatorio": False, "dica": "Opcional: se vazio, usa a mediana do treino"},
    {"nome": "BMI", "rotulo": "IMC", "unidade": "kg/m²", "min": 10, "max": 70, "passo": 0.1,
     "obrigatorio": True, "dica": "Peso em kg dividido pela altura em metros ao quadrado"},
    {"nome": "DiabetesPedigreeFunction", "rotulo": "Índice de histórico familiar", "unidade": "", "min": 0.05,
     "max": 2.5, "passo": 0.001, "obrigatorio": True, "dica": "Típico: 0,1 a 1,2 (maior = mais casos na família)"},
    {"nome": "Age", "rotulo": "Idade", "unidade": "anos", "min": 18, "max": 100, "passo": 1,
     "obrigatorio": True, "dica": "A base tem mulheres com 21 anos ou mais"},
]


def modelo_disponivel():
    return CAMINHO_MODELO.exists() and CAMINHO_METRICAS.exists()


def carregar_modelo():
    if "modelo" not in _cache:
        _cache["modelo"] = joblib.load(CAMINHO_MODELO)
    return _cache["modelo"]


def carregar_metricas():
    if "metricas" not in _cache:
        _cache["metricas"] = json.loads(CAMINHO_METRICAS.read_text(encoding="utf-8"))
    return _cache["metricas"]


def validar_formulario(form):
    """Converte os campos em números e confere os limites. Retorna (valores, erros)."""
    valores, erros = {}, []
    for c in CAMPOS:
        bruto = (form.get(c["nome"]) or "").strip().replace(",", ".")
        if bruto == "":
            if c["obrigatorio"]:
                erros.append(f"Preencha o campo '{c['rotulo']}'.")
            else:
                valores[c["nome"]] = np.nan  # o imputador do pipeline usa a mediana do treino
            continue
        try:
            numero = float(bruto)
        except ValueError:
            erros.append(f"'{c['rotulo']}' precisa ser um número (você digitou '{bruto}').")
            continue
        if not np.isfinite(numero) or not (c["min"] <= numero <= c["max"]):
            unidade = f" {c['unidade']}" if c["unidade"] else ""
            erros.append(f"'{c['rotulo']}' deve estar entre {c['min']} e {c['max']}{unidade}.")
            continue
        valores[c["nome"]] = numero
    return valores, erros


def prever(valores):
    """Monta uma linha com as MESMAS colunas e ordem do treino e executa predict()."""
    linha = pd.DataFrame([[valores[c] for c in COLUNAS_X]], columns=COLUNAS_X)
    modelo = carregar_modelo()
    classe = int(modelo.predict(linha)[0])
    prob = modelo.predict_proba(linha)[0]
    return {
        "classe": classe,
        "rotulo": ROTULOS_CLASSE[classe],
        "prob_diabetes": float(prob[1]),
        "prob_classe": float(prob[classe]),
    }
