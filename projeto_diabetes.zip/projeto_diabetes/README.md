# Diabetes Pima: análise de dados e previsão com Machine Learning

Trabalho Final de Tópicos Especiais em Ciência da Computação. **Tema 12: Diabetes** (Pima Indians Diabetes / OpenML 37).

## Equipe e responsabilidades

> Preencher com os nomes e o que cada integrante fez (o enunciado exige este registro).

| Integrante | Responsabilidade |
|---|---|
| (nome) | dados e gráficos (`dados.py`) |
| (nome) | modelos e avaliação (`treinar.py`) |
| (nome) | Flask, upload e validação (`app.py`) |
| (nome) | formulário, previsão e documentação (`modelo.py`, templates) |

## Pergunta do projeto

É possível prever se uma paciente tem diabetes a partir de medidas clínicas básicas?

## Instalação e execução

Requer Python 3.10+.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python baixar_dados.py           # baixa o dataset (precisa de internet) -> data/diabetes.csv
python treinar.py                # compara os modelos e salva models/modelo.joblib
python app.py                    # abre em http://127.0.0.1:5000
```

Se `baixar_dados.py` não funcionar, baixe `diabetes.csv` do Kaggle ("Pima Indians Diabetes Database") e salve em `data/diabetes.csv`. Ele já usa os mesmos nomes de coluna.

## Estrutura

| Arquivo | Função |
|---|---|
| `app.py` | rotas Flask: `/` (upload), `/analise`, `/modelos`, `/previsao` |
| `dados.py` | leitura, validação, limpeza, achados e gráficos (Pandas e Matplotlib) |
| `modelo.py` | carrega o modelo, valida o formulário e prevê |
| `treinar.py` | treino, comparação e avaliação dos modelos |
| `baixar_dados.py` | obtém o dataset e converte para CSV |
| `templates/`, `static/` | páginas HTML e CSS |
| `data/` | CSV da base e `exemplo_invalido.csv` (para demonstrar a validação) |
| `models/` | `modelo.joblib` e `metricas.json` gerados por `treinar.py` |
| `uploads/` | cópia dos CSV enviados, sem alterações |

## Esquema do CSV

Cada linha é uma paciente. Nove colunas obrigatórias (colunas extras são ignoradas). O separador pode ser vírgula ou ponto e vírgula; decimal com vírgula é aceito.

| Coluna | Significado | Unidade | Limites aceitos no CSV |
|---|---|---|---|
| Pregnancies | número de gestações | | 0 a 25 |
| Glucose | glicose 2 h após teste oral | mg/dL | 1 a 600 |
| BloodPressure | pressão diastólica | mm Hg | 1 a 250 |
| SkinThickness | dobra cutânea do tríceps | mm | 1 a 120 |
| Insulin | insulina sérica de 2 h | mu U/ml | 1 a 1500 |
| BMI | índice de massa corporal | kg/m² | 1 a 80 |
| DiabetesPedigreeFunction | histórico familiar | índice | 0,001 a 5 |
| Age | idade | anos | 18 a 120 |
| Outcome | **alvo**: 0 = sem diabetes, 1 = com diabetes | | 0 ou 1 |

**Validações**: arquivo vazio, extensão, separador, colunas obrigatórias ausentes, valores não numéricos, `Outcome` diferente de 0/1, menos de 30 registros após a limpeza e ausência de uma das classes. Cada erro aparece em linguagem simples na tela inicial.

## Dados, fonte e licença

Pima Indians Diabetes (National Institute of Diabetes and Digestive and Kidney Diseases), disponível no OpenML (id 37) e no repositório UCI. Confirmar a licença na página da fonte antes da entrega. **Limite da população:** só mulheres de origem Pima com 21 anos ou mais; o modelo não vale para outros grupos.

## Limpeza (e por quê)

O CSV original nunca é alterado; as transformações acontecem em uma cópia e são listadas na página de análise.

- **Zeros impossíveis** em `Glucose`, `BloodPressure`, `SkinThickness`, `Insulin` e `BMI`: viram ausente (NaN), pois 0 significa "não medido". Apagar os registros descartaria muitas pacientes (insulina e dobra cutânea têm centenas de zeros).
- **Valores absurdos** em idade, gestações e histórico familiar: o registro é removido (provável erro de digitação).
- **Duplicatas** exatas e registros sem `Outcome`: removidos.
- **Ausentes restantes**: preenchidos pela **mediana do treino** dentro do `Pipeline` (`SimpleImputer`), para não vazar informação do teste.

## X e y

- **y**: `Outcome`.
- **X**: as 8 demais colunas. Todas são exames ou dados disponíveis no momento da consulta; não há ID nem variável que revele o alvo.

## Modelos e avaliação

- Divisão com `train_test_split`: 80% treino / 20% teste, `random_state=42`, `stratify=y`.
- Modelos (mesma divisão, mesmas métricas): Regressão Logística (com `StandardScaler`), Random Forest e Árvore de Decisão, todos com `class_weight="balanced"` por causa do desequilíbrio de classes.
- Métricas: acurácia (comparada com a linha de base da classe mais frequente), precisão, recall, F1, AUC e matriz de confusão. Em saúde, o **recall** da classe com diabetes pesa mais, pois falso negativo é o erro mais grave.
- **Escolha do modelo**: maior F1 médio em validação cruzada (5 folds) **apenas no treino**, para o teste não influenciar a decisão. O teste é usado uma vez para reportar o desempenho.
- O pipeline completo (imputador, escala e classificador) é salvo com `joblib`, então o formulário aplica o mesmo preparo do treino.

### Resultados

> Rode `python treinar.py` e copie aqui a tabela impressa (ou da página `/modelos`), com o modelo escolhido e a interpretação dos erros. Esses números dependem da base real baixada.

## Coerência entre upload e modelo

O CSV enviado atualiza análise e gráficos. O **modelo é fixo**: foi treinado com `data/diabetes.csv`. A página de previsão e a de análise informam qual arquivo (e qual versão, via hash) foi usado no treino.

## Limitações

- Base pequena e de uma única população; resultado depende de uma divisão.
- Muitos valores não medidos em insulina e dobra cutânea, preenchidos pela mediana.
- Projeto didático: não é diagnóstico médico.

## Ferramentas e uso de IA

> Seja específico e honesto aqui; o enunciado exige citar ferramentas, inclusive IA.

O esqueleto do projeto e o primeiro rascunho do código foram gerados com o assistente de IA Claude (Anthropic). O grupo revisou, executou e adaptou o código, e todos os integrantes devem saber explicá-lo. Bibliotecas: Flask, Pandas, scikit-learn, Matplotlib, joblib.
