
import base64
import io

import matplotlib

matplotlib.use("Agg")  # backend sem janela, necessário para rodar dentro do Flask
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

COLUNAS_X = [
    "Pregnancies",               # número de gestações
    "Glucose",                   # glicose após teste oral de tolerância (mg/dL)
    "BloodPressure",             # pressão arterial diastólica (mm Hg)
    "SkinThickness",             # dobra cutânea do tríceps (mm)
    "Insulin",                   # insulina sérica de 2 h (mu U/ml)
    "BMI",                       # índice de massa corporal (kg/m²)
    "DiabetesPedigreeFunction",  # histórico familiar de diabetes (índice)
    "Age",                       # idade (anos)
]
ALVO = "Outcome"                 # 0 = sem diabetes, 1 = com diabetes
COLUNAS = COLUNAS_X + [ALVO]

ZEROS_INVALIDOS = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]

LIMITES = {
    "Pregnancies": (0, 25),
    "Glucose": (1, 600),
    "BloodPressure": (1, 250),
    "SkinThickness": (1, 120),
    "Insulin": (1, 1500),
    "BMI": (1, 80),
    "DiabetesPedigreeFunction": (0.001, 5),
    "Age": (18, 120),
}

ROTULOS_CLASSE = {0: "Sem diabetes", 1: "Com diabetes"}
COR_CLASSE = {0: "#3b7f8c", 1: "#c24a2f"}


class ErroCSV(Exception):
    """Erro de validação com mensagem pensada para o usuário final."""


def ler_csv(conteudo: bytes):
    """Lê e valida o CSV. Retorna (DataFrame só com as colunas do esquema, avisos)."""
    if not conteudo or not conteudo.strip():
        raise ErroCSV("O arquivo está vazio. Envie um CSV com cabeçalho e pelo menos um registro.")

    try:
        texto = conteudo.decode("utf-8-sig")
    except UnicodeDecodeError:
        texto = conteudo.decode("latin-1")

    primeira = texto.splitlines()[0]
    sep = ";" if primeira.count(";") > primeira.count(",") else ","

    try:
        df = pd.read_csv(io.StringIO(texto), sep=sep)
    except Exception:
        raise ErroCSV("Não foi possível interpretar o arquivo como CSV. "
                      "Confira se ele é texto separado por vírgula ou ponto e vírgula.")

    df.columns = [str(c).strip() for c in df.columns]
    if df.empty:
        raise ErroCSV("O arquivo tem cabeçalho, mas nenhum registro.")

    faltando = [c for c in COLUNAS if c not in df.columns]
    if faltando:
        raise ErroCSV(
            f"Colunas obrigatórias ausentes: {', '.join(faltando)}. "
            f"Colunas encontradas (separador '{sep}'): {', '.join(df.columns)}."
        )

    avisos = []
    extras = [c for c in df.columns if c not in COLUNAS]
    if extras:
        avisos.append(f"Colunas ignoradas por não fazerem parte do esquema: {', '.join(extras)}.")
    df = df[COLUNAS].copy()

    problemas = []
    for c in COLUNAS:
        serie = df[c]
        if not pd.api.types.is_numeric_dtype(serie):
            serie = (serie.astype(str).str.strip().str.replace(",", ".", regex=False)
                     .replace({"": np.nan, "nan": np.nan, "NaN": np.nan}))
        numerica = pd.to_numeric(serie, errors="coerce")
        invalidos = numerica.isna() & serie.notna()
        if invalidos.any():
            exemplo = serie[invalidos].iloc[0]
            problemas.append(f"'{c}': {int(invalidos.sum())} valor(es) não numérico(s) (ex.: '{exemplo}')")
        df[c] = numerica
    if problemas:
        raise ErroCSV("Valores incompatíveis encontrados: " + "; ".join(problemas) + ".")

    fora = df[ALVO].dropna()
    if not fora.isin([0, 1]).all():
        raise ErroCSV("A coluna 'Outcome' deve conter apenas 0 (sem diabetes) ou 1 (com diabetes).")

    return df, avisos


def limpar(df: pd.DataFrame):
    """
    Aplica o tratamento e registra cada transformação.
    O DataFrame recebido NÃO é alterado (o CSV original fica preservado).
    Retorna (df_limpo, log, diagnostico).
    """
    log = []
    diag = {"antes": len(df)}
    diag["nulos_originais"] = {c: int(df[c].isna().sum()) for c in COLUNAS if df[c].isna().any()}
    d = df.copy()

    n = int(d[ALVO].isna().sum())
    if n:
        d = d.dropna(subset=[ALVO])
        log.append(f"Removidos {n} registro(s) sem valor em 'Outcome' (sem resposta conhecida).")

    n = int(d.duplicated().sum())
    diag["duplicatas"] = n
    if n:
        d = d.drop_duplicates()
        log.append(f"Removidos {n} registro(s) duplicado(s) para não contar a mesma paciente duas vezes.")

    zeros, fora_limite, remover = {}, {}, pd.Series(False, index=d.index)
    for c in COLUNAS_X:
        lo, hi = LIMITES[c]
        invalido = d[c].notna() & ((d[c] < lo) | (d[c] > hi))
        if c in ZEROS_INVALIDOS:
            n0 = int((d[c] == 0).sum())
            nf = int(invalido.sum()) - n0
            if n0:
                zeros[c] = n0
            if invalido.any():
                d.loc[invalido, c] = np.nan
                log.append(f"'{c}': {int(invalido.sum())} valor(es) impossível(is) "
                           f"({n0} zero(s)) convertido(s) em ausente; não foram apagados registros.")
            if nf > 0:
                fora_limite[c] = nf
        elif invalido.any():
            remover |= invalido
            fora_limite[c] = int(invalido.sum())
    if remover.any():
        d = d[~remover]
        log.append(f"Removidos {int(remover.sum())} registro(s) com idade, gestações ou histórico familiar impossíveis.")
    diag["zeros_invalidos"] = zeros
    diag["fora_limite"] = fora_limite

    d = d.reset_index(drop=True)
    diag["nulos_finais"] = {c: int(d[c].isna().sum()) for c in COLUNAS_X if d[c].isna().any()}
    diag["depois"] = len(d)
    diag["tipos"] = {c: str(t) for c, t in df.dtypes.items()}

    if diag["nulos_finais"]:
        log.append("Valores ausentes foram MANTIDOS nesta etapa. No treinamento, eles são preenchidos pela "
                   "mediana calculada só no conjunto de treino (SimpleImputer dentro do Pipeline), "
                   "o que evita vazamento de dados.")
    if not log:
        log.append("Nenhuma correção foi necessária neste arquivo.")
    return d, log, diag


def validar_minimo(df: pd.DataFrame):
    """A análise precisa de registros suficientes e das duas classes."""
    if len(df) < 30:
        raise ErroCSV(f"Após a limpeza restaram apenas {len(df)} registros. São necessários pelo menos 30.")
    if df[ALVO].nunique() < 2:
        raise ErroCSV("O arquivo contém apenas uma classe em 'Outcome'. É preciso ter 0 e 1 para comparar os grupos.")


def achados(df: pd.DataFrame):
    """Gera achados interpretados a partir dos números do próprio arquivo."""
    res = []
    pos = df[ALVO].mean()
    res.append(
        f"Desequilíbrio de classes: {pos:.1%} das pacientes têm diabetes e {1 - pos:.1%} não têm. "
        f"Um 'modelo' que respondesse sempre a classe mais comum acertaria {max(pos, 1 - pos):.1%}; "
        "é esse o valor a superar na avaliação."
    )

    med = df.groupby(ALVO)["Glucose"].median()
    res.append(
        f"A glicose difere entre os grupos: a mediana é {med[1]:.0f} mg/dL em quem tem diabetes e "
        f"{med[0]:.0f} mg/dL em quem não tem (diferença de {med[1] - med[0]:.0f} mg/dL)."
    )

    faixas = pd.cut(df["Age"], [0, 29, 44, 200], labels=["até 29 anos", "30 a 44 anos", "45 anos ou mais"])
    taxa = df.groupby(faixas, observed=True)[ALVO].agg(["mean", "size"])
    partes = [f"{idx}: {linha['mean']:.0%} (n={int(linha['size'])})" for idx, linha in taxa.iterrows()]
    res.append("A frequência de diabetes muda com a idade. Por faixa etária: " + "; ".join(partes) + ".")

    d2 = df.dropna(subset=["BMI"])
    obesas, demais = d2[d2["BMI"] >= 30], d2[d2["BMI"] < 30]
    if len(obesas) and len(demais):
        res.append(
            f"Entre pacientes com IMC ≥ 30, {obesas[ALVO].mean():.0%} têm diabetes; "
            f"entre as com IMC < 30, {demais[ALVO].mean():.0%}."
        )

    corr = df.corr(numeric_only=True)[ALVO].drop(ALVO).dropna()
    if len(corr):
        top = corr.abs().sort_values(ascending=False).index[0]
        res.append(
            f"A variável com maior correlação linear com o alvo é '{top}' (r = {corr[top]:.2f}), "
            "o que a torna uma candidata forte a ajudar o modelo."
        )
    return res


def _para_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _estilo(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.25)


def _outliers_iqr(s):
    q1, q3 = s.quantile([0.25, 0.75])
    iqr = q3 - q1
    return int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())


def graficos(df: pd.DataFrame):
    """Retorna 4 gráficos (distribuição, comparação, 2 relações) com título, eixos e interpretação."""
    saida = []
    g = {c: df.loc[df[ALVO] == c, "Glucose"].dropna() for c in (0, 1)}

    # 1) DISTRIBUIÇÃO: histograma de glicose por classe
    fig, ax = plt.subplots(figsize=(7, 4))
    for c in (0, 1):
        ax.hist(g[c], bins=20, alpha=0.65, color=COR_CLASSE[c], label=ROTULOS_CLASSE[c])
    ax.set_title("Distribuição da glicose por grupo")
    ax.set_xlabel("Glicose (mg/dL)")
    ax.set_ylabel("Número de pacientes")
    ax.legend(frameon=False)
    _estilo(ax)
    q0, q1 = g[0].quantile([0.25, 0.75]), g[1].quantile([0.25, 0.75])
    comp = "maior" if g[1].std() > g[0].std() else "menor"
    saida.append({
        "titulo": "Distribuição da glicose por grupo",
        "img": _para_base64(fig),
        "texto": (f"Sem diabetes, metade das pacientes fica entre {q0[0.25]:.0f} e {q0[0.75]:.0f} mg/dL "
                  f"(desvio-padrão {g[0].std():.0f}). Com diabetes, a faixa central vai de "
                  f"{q1[0.25]:.0f} a {q1[0.75]:.0f} mg/dL e a dispersão é {comp} "
                  f"(desvio-padrão {g[1].std():.0f}). Valor mais alto observado: {g[0].max():.0f} mg/dL sem diabetes "
                  f"e {g[1].max():.0f} mg/dL com diabetes. Onde as duas distribuições se sobrepõem, "
                  "a glicose sozinha não decide o grupo e errar é mais provável."),
    })

    # 2) COMPARAÇÃO: contagem de cada classe
    cont = df[ALVO].value_counts().reindex([0, 1]).fillna(0).astype(int)
    fig, ax = plt.subplots(figsize=(5.5, 4))
    barras = ax.bar([ROTULOS_CLASSE[0], ROTULOS_CLASSE[1]], cont.values,
                    color=[COR_CLASSE[0], COR_CLASSE[1]])
    for b, v in zip(barras, cont.values):
        ax.text(b.get_x() + b.get_width() / 2, v, f"{v} ({v / cont.sum():.0%})", ha="center", va="bottom")
    ax.set_title("Quantidade de pacientes por grupo")
    ax.set_xlabel("Grupo (variável alvo Outcome)")
    ax.set_ylabel("Número de pacientes")
    ax.set_ylim(0, cont.max() * 1.15)
    _estilo(ax)
    saida.append({
        "titulo": "Quantidade de pacientes por grupo",
        "img": _para_base64(fig),
        "texto": (f"Há {cont[0]} pacientes sem diabetes e {cont[1]} com diabetes: as classes são desbalanceadas "
                  f"(proporção de {cont[0] / max(cont[1], 1):.1f} para 1). Por isso a acurácia sozinha engana, "
                  "e a avaliação precisa olhar também recall e precisão da classe com diabetes."),
    })

    # 3) RELAÇÃO: boxplot de glicose por classe
    fig, ax = plt.subplots(figsize=(5.5, 4))
    bp = ax.boxplot([g[0], g[1]], tick_labels=[ROTULOS_CLASSE[0], ROTULOS_CLASSE[1]], patch_artist=True,
                    medianprops={"color": "black"})
    for caixa, c in zip(bp["boxes"], (0, 1)):
        caixa.set_facecolor(COR_CLASSE[c])
        caixa.set_alpha(0.7)
    ax.set_title("Glicose por grupo (boxplot)")
    ax.set_xlabel("Grupo (variável alvo Outcome)")
    ax.set_ylabel("Glicose (mg/dL)")
    _estilo(ax)
    saida.append({
        "titulo": "Glicose por grupo (boxplot)",
        "img": _para_base64(fig),
        "texto": (f"A mediana é {g[1].median():.0f} mg/dL no grupo com diabetes e {g[0].median():.0f} mg/dL no grupo "
                  f"sem diabetes (diferença de {g[1].median() - g[0].median():+.0f} mg/dL), então a glicose carrega "
                  f"informação sobre o alvo. Pontos isolados são valores extremos pela regra do IQR: "
                  f"{_outliers_iqr(g[0])} no grupo sem diabetes e {_outliers_iqr(g[1])} no grupo com diabetes."),
    })

    # 4) RELAÇÃO: dispersão glicose x IMC
    d2 = df.dropna(subset=["Glucose", "BMI"])
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for c in (0, 1):
        s = d2[d2[ALVO] == c]
        ax.scatter(s["Glucose"], s["BMI"], s=18, alpha=0.6, color=COR_CLASSE[c], label=ROTULOS_CLASSE[c])
    ax.set_title("Glicose × IMC")
    ax.set_xlabel("Glicose (mg/dL)")
    ax.set_ylabel("IMC (kg/m²)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25)
    ax.spines[["top", "right"]].set_visible(False)
    regiao = d2[(d2["Glucose"] >= 140) & (d2["BMI"] >= 30)]
    txt_regiao = (f"Na região de glicose ≥ 140 e IMC ≥ 30 ({len(regiao)} pacientes), {regiao[ALVO].mean():.0%} "
                  "têm diabetes." if len(regiao) else "")
    saida.append({
        "titulo": "Glicose × IMC",
        "img": _para_base64(fig),
        "texto": (f"Cada ponto é uma paciente. A correlação entre glicose e IMC é "
                  f"{d2['Glucose'].corr(d2['BMI']):.2f}. " + txt_regiao +
                  " Quando os dois grupos se misturam no gráfico, nenhuma das duas variáveis separa os grupos "
                  "sozinha, o que justifica um modelo com várias entradas."),
    })
    return saida


def grafico_matriz(matriz, titulo):
    """Matriz de confusão com eixos real × previsto (matriz = [[VN, FP], [FN, VP]])."""
    matriz = np.array(matriz)
    nomes = [ROTULOS_CLASSE[0], ROTULOS_CLASSE[1]]
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.imshow(matriz, cmap="Blues")
    ax.set_xticks([0, 1], labels=nomes)
    ax.set_yticks([0, 1], labels=nomes)
    ax.set_xlabel("Classe prevista")
    ax.set_ylabel("Classe real")
    ax.set_title(titulo)
    limite = matriz.max() / 2
    for i in range(2):
        for j in range(2):
            ax.text(j, i, int(matriz[i, j]), ha="center", va="center",
                    color="white" if matriz[i, j] > limite else "black", fontsize=14)
    return _para_base64(fig)
