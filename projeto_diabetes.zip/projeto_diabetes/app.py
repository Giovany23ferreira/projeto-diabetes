
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

import dados
import modelo

RAIZ = Path(__file__).parent
BASE_EXEMPLO = RAIZ / "data" / "diabetes.csv"
PASTA_UPLOADS = RAIZ / "uploads"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB


def analisar(conteudo: bytes, nome_arquivo: str):
    """Valida, limpa e analisa um CSV. Levanta ErroCSV se algo estiver errado."""
    original, avisos = dados.ler_csv(conteudo)
    limpo, log, diag = dados.limpar(original)  # 'original' não é alterado
    dados.validar_minimo(limpo)
    return {
        "nome_arquivo": nome_arquivo,
        "n_colunas": len(original.columns),
        "diag": diag,
        "log": log,
        "avisos": avisos,
        "amostra": limpo.head(10).to_html(classes="tabela", index=False, na_rep="—", border=0, float_format="%.2f"),
        "achados": dados.achados(limpo),
        "graficos": dados.graficos(limpo),
        "metricas": modelo.carregar_metricas() if modelo.modelo_disponivel() else None,
    }


@app.route("/")
def index():
    return render_template("index.html", base_existe=BASE_EXEMPLO.exists(), colunas=modelo.CAMPOS,
                           limites=dados.LIMITES)


@app.route("/analise", methods=["GET", "POST"])
def analise():
    try:
        if request.method == "POST":
            arquivo = request.files.get("arquivo")
            if arquivo is None or arquivo.filename == "":
                raise dados.ErroCSV("Selecione um arquivo CSV antes de enviar.")
            if not arquivo.filename.lower().endswith(".csv"):
                raise dados.ErroCSV("O arquivo precisa ter extensão .csv.")
            conteudo = arquivo.read()
            if conteudo.strip():
                # guarda o CSV original, sem alterações, com data e hora
                carimbo = datetime.now().strftime("%Y%m%d_%H%M%S")
                (PASTA_UPLOADS / f"{carimbo}_{secure_filename(arquivo.filename)}").write_bytes(conteudo)
            contexto = analisar(conteudo, arquivo.filename)
        else:
            if not BASE_EXEMPLO.exists():
                raise dados.ErroCSV("A base de exemplo não foi encontrada. Rode 'python baixar_dados.py' "
                                    "ou envie seu próprio CSV.")
            contexto = analisar(BASE_EXEMPLO.read_bytes(), BASE_EXEMPLO.name + " (base de exemplo)")
    except dados.ErroCSV as e:
        return render_template("index.html", erro=str(e), base_existe=BASE_EXEMPLO.exists(),
                               colunas=modelo.CAMPOS, limites=dados.LIMITES), 400
    return render_template("analise.html", **contexto)


@app.route("/modelos")
def modelos():
    if not modelo.modelo_disponivel():
        return render_template("modelos.html", metricas=None)
    metricas = modelo.carregar_metricas()
    matrizes = [{"nome": m["nome"], "img": dados.grafico_matriz(m["matriz"], m["nome"]),
                 "escolhido": m["nome"] == metricas["escolhido"]} for m in metricas["modelos"]]
    return render_template("modelos.html", metricas=metricas, matrizes=matrizes)


@app.route("/previsao", methods=["GET", "POST"])
def previsao():
    if not modelo.modelo_disponivel():
        return render_template("previsao.html", campos=modelo.CAMPOS, metricas=None, form={})
    metricas = modelo.carregar_metricas()
    contexto = {"campos": modelo.CAMPOS, "metricas": metricas, "form": {}, "erros": [], "resultado": None}
    if request.method == "POST":
        contexto["form"] = request.form
        valores, erros = modelo.validar_formulario(request.form)
        if erros:
            contexto["erros"] = erros
        else:
            contexto["resultado"] = modelo.prever(valores)
    return render_template("previsao.html", **contexto)


@app.errorhandler(413)
def arquivo_grande(_):
    return render_template("index.html", erro="O arquivo excede o limite de 5 MB.",
                           base_existe=BASE_EXEMPLO.exists(), colunas=modelo.CAMPOS,
                           limites=dados.LIMITES), 413


if __name__ == "__main__":
    app.run(debug=True)
